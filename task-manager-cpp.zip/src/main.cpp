#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Task {
    string title;
    string description;
    string deadline;
    string priority;
    bool completed = false;
};

map<string, vector<Task>> taskManager;

void addTask() {
    Task newTask;
    string category;

    cin.ignore();
    cout << "Enter task category: ";
    getline(cin, category);

    cout << "Enter title: ";
    getline(cin, newTask.title);

    cout << "Enter description: ";
    getline(cin, newTask.description);

    cout << "Enter deadline (DD-MM-YYYY): ";
    getline(cin, newTask.deadline);

    cout << "Enter priority (High/Medium/Low): ";
    getline(cin, newTask.priority);

    taskManager[category].push_back(newTask);
    cout << "Task added successfully!\n";
}

void viewTasks() {
    for (const auto& pair : taskManager) {
        cout << "\nCategory: " << pair.first << endl;
        for (size_t i = 0; i < pair.second.size(); ++i) {
            const Task& task = pair.second[i];
            cout << "  [" << i + 1 << "] "
                 << (task.completed ? "[Completed] " : "")
                 << "Title: " << task.title
                 << ", Deadline: " << task.deadline
                 << ", Priority: " << task.priority
                 << "\n    Description: " << task.description << "\n";
        }
    }
}

void markTaskCompleted() {
    string category;
    int index;

    cin.ignore();
    cout << "Enter category: ";
    getline(cin, category);

    if (taskManager.find(category) == taskManager.end()) {
        cout << "Category not found!\n";
        return;
    }

    cout << "Enter task number to mark completed: ";
    cin >> index;

    if (index > 0 && index <= taskManager[category].size()) {
        taskManager[category][index - 1].completed = true;
        cout << "Task marked as completed!\n";
    } else {
        cout << "Invalid task number!\n";
    }
}

void removeCompletedTasks() {
    for (auto& pair : taskManager) {
        auto& tasks = pair.second;
        tasks.erase(remove_if(tasks.begin(), tasks.end(),
            [](const Task& task) { return task.completed; }), tasks.end());
    }
    cout << "All completed tasks removed.\n";
}

void deleteTask() {
    string category;
    int index;

    cin.ignore();
    cout << "Enter category: ";
    getline(cin, category);

    if (taskManager.find(category) == taskManager.end()) {
        cout << "Category not found!\n";
        return;
    }

    cout << "Enter task number to delete: ";
    cin >> index;

    if (index > 0 && index <= taskManager[category].size()) {
        taskManager[category].erase(taskManager[category].begin() + index - 1);
        cout << "Task deleted.\n";
    } else {
        cout << "Invalid task number!\n";
    }
}

void editTask() {
    string category;
    int index;

    cin.ignore();
    cout << "Enter category: ";
    getline(cin, category);

    if (taskManager.find(category) == taskManager.end()) {
        cout << "Category not found!\n";
        return;
    }

    cout << "Enter task number to edit: ";
    cin >> index;
    cin.ignore();

    if (index > 0 && index <= taskManager[category].size()) {
        Task& task = taskManager[category][index - 1];

        cout << "Enter new title (or press Enter to keep \"" << task.title << "\"): ";
        string input;
        getline(cin, input);
        if (!input.empty()) task.title = input;

        cout << "Enter new description: ";
        getline(cin, task.description);

        cout << "Enter new deadline: ";
        getline(cin, task.deadline);

        cout << "Enter new priority: ";
        getline(cin, task.priority);

        cout << "Task updated.\n";
    } else {
        cout << "Invalid task number!\n";
    }
}

int main() {
    int choice;

    while (true) {
        cout << "\n---- Task Manager ----\n";
        cout << "1. Add Task\n";
        cout << "2. View Tasks\n";
        cout << "3. Mark Task as Completed\n";
        cout << "4. Delete Task\n";
        cout << "5. Edit Task\n";
        cout << "6. Remove Completed Tasks\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addTask(); break;
            case 2: viewTasks(); break;
            case 3: markTaskCompleted(); break;
            case 4: deleteTask(); break;
            case 5: editTask(); break;
            case 6: removeCompletedTasks(); break;
            case 0: cout << "Exiting...\n"; return 0;
            default: cout << "Invalid choice. Try again.\n";
        }
    }
}
