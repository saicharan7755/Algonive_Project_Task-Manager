#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// ===== Task Structure =====
// Represents a single task with relevant details
struct Task {
    string description;
    string category;
    string dueDate;   // Format: YYYY-MM-DD
    int priority;     // 1 = High, 2 = Medium, 3 = Low
    bool isCompleted;

    // Constructor
    Task(string desc, string cat, string date, int pri)
        : description(desc), category(cat), dueDate(date), priority(pri), isCompleted(false) {}
};

// ===== Global Task List =====
vector<Task> tasks;

// ===== Function Declarations =====
void displayMenu();
void addTask();
void viewTasksSortedByDueDate();
void viewTasksSortedByPriority();
void markTaskAsCompleted();
void removeCompletedTasks();
void displayTask(const Task& task, int index);

// ===== Entry Point =====
int main() {
    int choice;

    do {
        displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();  // Clear input buffer

        switch (choice) {
            case 1: addTask(); break;
            case 2: viewTasksSortedByDueDate(); break;
            case 3: viewTasksSortedByPriority(); break;
            case 4: markTaskAsCompleted(); break;
            case 5: removeCompletedTasks(); break;
            case 0: cout << "\nExiting Task Management System. Goodbye!\n"; break;
            default: cout << "\nInvalid choice. Please try again.\n";
        }

    } while (choice != 0);

    return 0;
}

// ===== Menu Display =====
void displayMenu() {
    cout << "\n======================================\n";
    cout << "         TASK MANAGEMENT SYSTEM       \n";
    cout << "======================================\n";
    cout << "1. Add a New Task\n";
    cout << "2. View Tasks Sorted by Due Date\n";
    cout << "3. View Tasks Sorted by Priority\n";
    cout << "4. Mark a Task as Completed\n";
    cout << "5. Remove All Completed Tasks\n";
    cout << "0. Exit Program\n";
    cout << "--------------------------------------\n";
}

// ===== Add New Task =====
void addTask() {
    string description, category, dueDate;
    int priority;

    cout << "\n--- Add New Task ---\n";
    cout << "Enter task description: ";
    getline(cin, description);

    cout << "Enter category (e.g., Work, Personal, Urgent): ";
    getline(cin, category);

    cout << "Enter due date (YYYY-MM-DD): ";
    getline(cin, dueDate);

    cout << "Enter priority (1 = High, 2 = Medium, 3 = Low): ";
    cin >> priority;
    cin.ignore();

    // Add the task to the list
    tasks.emplace_back(description, category, dueDate, priority);
    cout << "Task added successfully!\n";
}

// ===== View Tasks by Due Date =====
void viewTasksSortedByDueDate() {
    if (tasks.empty()) {
        cout << "\nNo tasks to display.\n";
        return;
    }

    cout << "\n--- Tasks Sorted by Due Date ---\n";

    // Sort tasks by due date (lexicographically)
    vector<Task> sortedTasks = tasks;
    sort(sortedTasks.begin(), sortedTasks.end(), [](const Task& a, const Task& b) {
        return a.dueDate < b.dueDate;
    });

    // Display tasks
    for (size_t i = 0; i < sortedTasks.size(); ++i) {
        displayTask(sortedTasks[i], static_cast<int>(i + 1));
    }
}

// ===== View Tasks by Priority =====
void viewTasksSortedByPriority() {
    if (tasks.empty()) {
        cout << "\nNo tasks to display.\n";
        return;
    }

    cout << "\n--- Tasks Sorted by Priority ---\n";

    // Sort tasks by priority (1 = High comes first)
    vector<Task> sortedTasks = tasks;
    sort(sortedTasks.begin(), sortedTasks.end(), [](const Task& a, const Task& b) {
        return a.priority < b.priority;
    });

    // Display tasks
    for (size_t i = 0; i < sortedTasks.size(); ++i) {
        displayTask(sortedTasks[i], static_cast<int>(i + 1));
    }
}

// ===== Display a Single Task =====
void displayTask(const Task& task, int index) {
    cout << "\nTask #" << index << ":\n";
    cout << "Description: " << task.description << "\n";
    cout << "Category   : " << task.category << "\n";
    cout << "Due Date   : " << task.dueDate << "\n";
    cout << "Priority   : ";

    switch (task.priority) {
        case 1: cout << "High\n"; break;
        case 2: cout << "Medium\n"; break;
        case 3: cout << "Low\n"; break;
        default: cout << "Unknown\n"; break;
    }

    cout << "Status     : " << (task.isCompleted ? "Completed" : "Pending") << "\n";
}

// ===== Mark Task as Completed =====
void markTaskAsCompleted() {
    if (tasks.empty()) {
        cout << "\nNo tasks available to mark as completed.\n";
        return;
    }

    cout << "\n--- Mark Task as Completed ---\n";
    for (size_t i = 0; i < tasks.size(); ++i) {
        cout << i + 1 << ". " << tasks[i].description << " [" 
             << (tasks[i].isCompleted ? "Completed" : "Pending") << "]\n";
    }

    int taskNumber;
    cout << "\nEnter the task number to mark as completed: ";
    cin >> taskNumber;
    cin.ignore();

    if (taskNumber >= 1 && taskNumber <= static_cast<int>(tasks.size())) {
        tasks[taskNumber - 1].isCompleted = true;
        cout << "Task marked as completed.\n";
    } else {
        cout << "Invalid task number.\n";
    }
}

// ===== Remove Completed Tasks =====
void removeCompletedTasks() {
    if (tasks.empty()) {
        cout << "\nNo tasks to remove.\n";
        return;
    }

    size_t beforeCount = tasks.size();

    // Remove tasks marked as completed
    tasks.erase(remove_if(tasks.begin(), tasks.end(), [](const Task& task) {
        return task.isCompleted;
    }), tasks.end());

    size_t afterCount = tasks.size();
    size_t removed = beforeCount - afterCount;

    cout << "\n" << removed << " completed task(s) removed.\n";
}
