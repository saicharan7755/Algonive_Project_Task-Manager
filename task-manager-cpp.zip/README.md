# Task Manager in C++

A simple console-based Task Manager application in C++ that lets you:

- Add tasks under categories
- Set deadlines and priorities
- View and edit tasks
- Mark tasks as completed
- Delete or clean up completed tasks

## 🛠 Features

- Task categorization
- Deadlines and priority (High/Medium/Low)
- Task editing and deletion
- Remove completed tasks

## 📂 Structure

```
task-manager-cpp/
├── src/
│   └── main.cpp
├── include/
├── .gitignore
├── README.md
└── LICENSE
```

## 🔧 Compilation

To compile using `g++`:

```bash
g++ src/main.cpp -o task-manager
./task-manager
```

## 📄 License

MIT License – see `LICENSE` for more info.
